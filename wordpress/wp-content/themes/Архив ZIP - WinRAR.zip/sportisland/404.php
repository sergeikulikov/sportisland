<?php
get_header();
?>

<main class="main-content">
    <div class="wrapper">
        <h1 class="main-heading schedule-page__h">404</h1>
    </div>
</main>

<?php
get_footer();
?>
