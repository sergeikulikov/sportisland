<section class="last-posts">
    <div class="wrapper">
        <h2 class="main-heading last-posts__h">Записи отсутствуют</h2>
    </div>
</section>